const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");
const taskCount = document.getElementById("taskCount");
const filters = document.querySelectorAll(".filter");

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let currentFilter = "all";

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
  taskList.innerHTML = "";

  const filteredTasks = tasks.filter(task => {
    if (currentFilter === "active") return !task.completed;
    if (currentFilter === "completed") return task.completed;
    return true;
  });

  filteredTasks.forEach(task => {
    const li = document.createElement("li");
    li.className = "task";

    if (task.completed) li.classList.add("completed");

    li.innerHTML = `
      <input type="checkbox" class="complete" data-id="${task.id}"
        ${task.completed ? "checked" : ""}>
      <span>${escapeHTML(task.text)}</span>
      <button class="edit" data-id="${task.id}">Edit</button>
      <button class="delete" data-id="${task.id}">Delete</button>
    `;

    taskList.appendChild(li);
  });

  const activeTasks = tasks.filter(task => !task.completed).length;
  taskCount.textContent =
    `${activeTasks} active task${activeTasks !== 1 ? "s" : ""}`;
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function addTask() {
  const text = taskInput.value.trim();

  if (!text) {
    alert("Please enter a task");
    return;
  }

  tasks.push({
    id: Date.now(),
    text: text,
    completed: false
  });

  saveTasks();
  renderTasks();
  taskInput.value = "";
  taskInput.focus();
}

addBtn.addEventListener("click", addTask);

taskInput.addEventListener("keydown", event => {
  if (event.key === "Enter") addTask();
});

taskList.addEventListener("click", event => {
  const id = Number(event.target.dataset.id);

  if (event.target.classList.contains("delete")) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
  }

  if (event.target.classList.contains("edit")) {
    const task = tasks.find(task => task.id === id);
    const newText = prompt("Edit task:", task.text);

    if (newText !== null && newText.trim() !== "") {
      task.text = newText.trim();
      saveTasks();
      renderTasks();
    }
  }
});

taskList.addEventListener("change", event => {
  if (event.target.classList.contains("complete")) {
    const id = Number(event.target.dataset.id);
    const task = tasks.find(task => task.id === id);

    task.completed = event.target.checked;
    saveTasks();
    renderTasks();
  }
});

filters.forEach(filter => {
  filter.addEventListener("click", () => {
    filters.forEach(button => button.classList.remove("active"));
    filter.classList.add("active");
    currentFilter = filter.dataset.filter;
    renderTasks();
  });
});

renderTasks();
