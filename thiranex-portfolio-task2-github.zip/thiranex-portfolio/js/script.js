const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");
const themeBtn = document.getElementById("themeBtn");

if (menuBtn) {
  menuBtn.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(open));
    menuBtn.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
  });
}

const savedTheme = localStorage.getItem("theme");
if (savedTheme === "dark") {
  document.documentElement.setAttribute("data-theme", "dark");
}
if (themeBtn) {
  themeBtn.textContent = document.documentElement.getAttribute("data-theme") === "dark" ? "☀" : "☾";
  themeBtn.addEventListener("click", () => {
    const dark = document.documentElement.getAttribute("data-theme") === "dark";
    if (dark) {
      document.documentElement.removeAttribute("data-theme");
      localStorage.setItem("theme", "light");
      themeBtn.textContent = "☾";
    } else {
      document.documentElement.setAttribute("data-theme", "dark");
      localStorage.setItem("theme", "dark");
      themeBtn.textContent = "☀";
    }
  });
}

const form = document.getElementById("contactForm");
if (form) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    document.querySelectorAll(".error").forEach(el => el.textContent = "");
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const message = document.getElementById("message");
    let valid = true;

    if (!name.value.trim()) {
      document.getElementById("nameError").textContent = "Please enter your name.";
      valid = false;
    }
    if (!email.validity.valid || !email.value.trim()) {
      document.getElementById("emailError").textContent = "Please enter a valid email.";
      valid = false;
    }
    if (!message.value.trim()) {
      document.getElementById("messageError").textContent = "Please enter a message.";
      valid = false;
    }
    if (valid) {
      document.getElementById("formStatus").textContent = "Message submitted successfully!";
      form.reset();
    }
  });
}
