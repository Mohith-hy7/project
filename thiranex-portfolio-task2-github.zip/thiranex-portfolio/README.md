# Thiranex Internship - Task 2
## Advanced CSS3 & Responsive Architecture

### Included
- CSS Grid for page layouts
- Flexbox for navigation/components
- Mobile-first responsive media queries
- CSS custom properties
- Light/Dark theme toggle
- Responsive multi-page portfolio
- Accessible navigation and contact form
- Basic client-side form validation

### Run in VS Code
1. Extract the ZIP.
2. Open the `thiranex-portfolio` folder in VS Code.
3. Open `index.html`.
4. Use the Live Server extension, or open `index.html` directly in a browser.

### Customize
Replace `Mohith Hy`, email, project details, and other personal information with your actual details before submitting.

### GitHub
https://github.com/Mohith-hy7
